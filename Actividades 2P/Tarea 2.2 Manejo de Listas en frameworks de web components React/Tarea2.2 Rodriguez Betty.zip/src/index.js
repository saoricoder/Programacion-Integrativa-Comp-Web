import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Parking from './Parking';

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Parking />);



